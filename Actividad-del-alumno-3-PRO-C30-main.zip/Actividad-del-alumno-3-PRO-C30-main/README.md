Actividad del alumno 3 - PRO - C30
